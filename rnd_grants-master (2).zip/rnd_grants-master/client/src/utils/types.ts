export type Faculty = {
    name: string;
    email: string;
    dept: string;
};
