export default interface AuthToken {
    email: string,
    type: string,
    name: string,
}