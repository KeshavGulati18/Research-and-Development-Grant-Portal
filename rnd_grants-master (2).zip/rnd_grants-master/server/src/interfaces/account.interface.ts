export default interface Account {
    email: string,
    type: string,
    dept: string,
    name: string,
}