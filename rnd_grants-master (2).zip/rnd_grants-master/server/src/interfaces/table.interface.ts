export default interface Table {
    [column: string]: string[]
}